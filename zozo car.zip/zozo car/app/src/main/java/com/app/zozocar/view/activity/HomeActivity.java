package com.app.zozocar.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;



import com.app.zozocar.R;
import com.shivtechs.maplocationpicker.LocationPickerActivity;
import com.shivtechs.maplocationpicker.MapUtility;


public class HomeActivity extends AppCompatActivity {

    private TextView mTextMessage;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    Intent i =new Intent(HomeActivity.this, LocationPickerActivity.class); startActivityForResult(i, 12);
//                    PingPlacePicker.IntentBuilder builder = new PingPlacePicker.IntentBuilder();
//                    builder.setAndroidApiKey("AIzaSyDsz_iONrW-e1dp7ODy4_V8uv7pq4ndNH8")
//                            .setMapsApiKey("AIzaSyDsz_iONrW-e1dp7ODy4_V8uv7pq4ndNH8");
//
//                    // If you want to set a initial location rather then the current device location.
//                    // NOTE: enable_nearby_search MUST be true.
//                    // builder.setLatLng(new LatLng(37.4219999, -122.0862462))
//
//                    try {
//                        Intent placeIntent = builder.build(HomeActivity.this);
//                        startActivityForResult(placeIntent,12);
//                    }
//                    catch (Exception ex) {
//                        // Google Play services is not available...
//                    }
                   // Intent intent = new Intent(HomeActivity.this, PlacePicker.class);

//                    val intent = VanillaPlacePicker.Builder(this)
//                            .with(PickerType.MAP_WITH_AUTO_COMPLETE) // Select Picker type to enable autocompelte, map or both
//                            .withLocation(23.057582, 72.534458)
//                            .setPickerLanguage(PickerLanguage.HINDI) // Apply language to picker
//                            .setTintColor(R.color.colorPrimaryAmber) // Apply Tint color to Back, Clear button of AutoComplete UI
//                            /*
//                             * Configuration for AutoComplete UI
//                             */
//                            .setRegion("IN")
//                            .setLanguage("en")
//                            .isOpenNow(true) // Returns only those places that are open for business at the time the query is sent.
//                            .setAutoCompletePlaceHolder(R.drawable.ic_undraw_search) // To add custom place holder in autocomplete screen
//            ...
//
//                    /*
//                     * Configuration for Map UI
//                     */
//            .setMapType(MapType.SATELLITE) // Choose map type (Only applicable for map screen)
//                        .setMapStyle(R.raw.style_json) // containing the JSON style declaration for night-mode styling
//                        .setMapPinDrawable(android.R.drawable.ic_menu_mylocation) // To give custom pin image for map marker
//            ...
//
//            .build()
//
//                    startActivityForResult(intent, REQUEST_PLACE_PICKER)

                    mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_dashboard:
                    mTextMessage.setText(R.string.title_dashboard);
                    return true;
                case R.id.navigation_notifications:
                    mTextMessage.setText(R.string.title_notifications);
                    return true;
                    case R.id.navigation_notificati1ons:
                    mTextMessage.setText(R.string.title_notifications);
                    return true;

            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        MapUtility.apiKey = getResources().getString(R.string.api_key);

        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }

}
