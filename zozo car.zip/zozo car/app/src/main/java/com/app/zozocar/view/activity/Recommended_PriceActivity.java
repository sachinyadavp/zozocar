package com.app.zozocar.view.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.app.zozocar.R;

public class Recommended_PriceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recommended__price);
    }
}
